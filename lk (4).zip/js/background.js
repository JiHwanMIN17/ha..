images=["0.jpeg.jpg","1.jpeg.jpg","2.jpeg.jpg"];

const selectedImage=images[Math.floor(Math.random()*images.length)];

const bgimage=document.createElement("img");

bgimage.src=`img/${selectedImage}`;

document.body.appendChild(bgimage);